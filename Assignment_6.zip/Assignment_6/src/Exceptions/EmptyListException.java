package Exceptions;

public class EmptyListException extends Exception{
    public EmptyListException(String errMsg) {
        super(errMsg);
    }
}

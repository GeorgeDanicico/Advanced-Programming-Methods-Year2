package Exceptions;

public class AssignmentException extends Exception{
    public AssignmentException(String errorMessage) {
        super(errorMessage);
    }
}

package Exceptions;

public class HeapException extends Exception{
    public HeapException(String errMsg) {
        super(errMsg);
    }
}

package Exceptions;

public class VariableTypeException extends Exception{
    public VariableTypeException(String errorMsg) {
        super(errorMsg);
    }
}

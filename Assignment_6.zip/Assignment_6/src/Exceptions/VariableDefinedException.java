package Exceptions;

public class VariableDefinedException extends Exception{
    public VariableDefinedException(String errMsg) {
        super(errMsg);
    }

}

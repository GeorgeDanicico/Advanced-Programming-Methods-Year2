package Exceptions;

public class DivisionByZeroException extends Exception{
    public DivisionByZeroException(String errorMsg) {
        super(errorMsg);
    }
}

package Exceptions;

public class ExpressionException extends Exception{
    public ExpressionException(String errorMsg) {
        super(errorMsg);
    }
}

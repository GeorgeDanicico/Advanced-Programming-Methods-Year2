package Exceptions;

public class ListException extends Exception{
    public ListException(String errMsg) {
        super(errMsg);
    }

}

package Exceptions;

public class DeclaredVariableException extends Exception{
    public DeclaredVariableException(String errorMsg) {
        super(errorMsg);
    }
}

package Exceptions;

public class UndefinedException extends Exception{
    public UndefinedException(String errorMsg) {
        super(errorMsg);
    }
}

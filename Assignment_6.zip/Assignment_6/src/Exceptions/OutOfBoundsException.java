package Exceptions;

public class OutOfBoundsException extends Exception{
    public OutOfBoundsException(String errMsg) {
        super(errMsg);
    }
}

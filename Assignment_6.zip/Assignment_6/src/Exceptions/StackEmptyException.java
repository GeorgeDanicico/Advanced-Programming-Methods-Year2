package Exceptions;

public class StackEmptyException extends Exception{
    public StackEmptyException(String errorMsg) {
        super(errorMsg);
    }
}
